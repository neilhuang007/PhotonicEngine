#define RENDER_VERTEX

#include "/lib/constants.glsl"
#include "/lib/common.glsl"


in vec4 at_tangent;
in vec4 at_midBlock;
in vec4 mc_midTexCoord;
in vec4 mc_Entity;

out VertexData {
    vec4 color;
    vec2 lmcoord;
    vec2 texcoord;
    vec3 localPos;

    #ifdef RENDER_TERRAIN
        flat int blockId;

        #ifdef VELOCITY_ENABLED
            vec3 velocity;
        #endif

        #ifdef IRIS_FEATURE_FADE_VARIABLE
            flat float chunkFade;
        #endif
    #endif

    #ifdef RENDER_ENTITY
        vec3 localNormal;
    #else
        flat uint localNormal;
    #endif

    #if defined(WATER_WAVE_ENABLED) && defined(RENDER_TERRAIN) && defined(RENDER_TRANSLUCENT)
        float waveHeight;
        float waveStrength;
    #endif

    #if defined(MATERIAL_PBR_ENABLED) || defined(WATER_WAVE_ENABLED)
        flat uint localTangent;
        flat float localTangentW;
    #endif

    #ifdef MATERIAL_PARALLAX_ENABLED
        vec3 tangentViewPos;
        flat uint atlasTilePos;
        flat uint atlasTileSize;
        flat uint wrapMask;
    #endif
} vOut;


#ifdef RENDER_TERRAIN
    #ifdef MATERIAL_PARALLAX_ENABLED
        uniform usampler3D texVoxels;
    #endif

    #ifdef WIND_ENABLED
        uniform usampler2D texBlockWaving;
    #endif
#endif

uniform float far;
uniform ivec2 atlasSize;
uniform float windTime;
uniform float windTimeLast;
uniform float weatherStrength;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform bool firstPersonCamera;
uniform vec3 relativeEyePosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform vec2 taa_offset = vec2(0.0);


#include "/lib/buffers/scene.glsl"

#include "/lib/blocks.glsl"
#include "/lib/sampling/lightmap.glsl"
#include "/lib/octohedral.glsl"
#include "/lib/tbn.glsl"

#include "/lib/voxel.glsl"

#ifdef MATERIAL_PARALLAX_ENABLED
    #include "/lib/sampling/atlas.glsl"
#endif

#ifdef RENDER_TERRAIN
    #if defined(WATER_WAVE_ENABLED) && defined(RENDER_TRANSLUCENT)
        #include "/lib/water-waves.glsl"
    #endif

    #ifdef WIND_ENABLED
        #include "/lib/hash-noise.glsl"
        #include "/lib/wind-waving.glsl"
    #endif
#endif

#ifdef LIGHTING_HAND
    #include "/lib/lighting/hand.glsl"
#endif


void main() {
    vOut.texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    vOut.lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vOut.lmcoord = LightMapNorm(vOut.lmcoord);

    vOut.color = gl_Color;

    vec3 viewNormal = normalize(gl_NormalMatrix * gl_Normal);
    vec3 localNormal = mat3(gbufferModelViewInverse) * viewNormal;

    #ifdef RENDER_ENTITY
        vOut.localNormal = localNormal;
    #else
        vOut.localNormal = packUnorm2x16(OctEncode(localNormal));
    #endif

    #if defined(RENDER_TERRAIN) && defined(IRIS_FEATURE_FADE_VARIABLE)
        vOut.chunkFade = saturate(mc_chunkFade);
        if (mc_chunkFade < 0.0) vOut.chunkFade = 1.0;
    #endif

    vec3 viewPos = mul3(gl_ModelViewMatrix, gl_Vertex.xyz);
    vOut.localPos = mul3(gbufferModelViewInverse, viewPos);

    #ifdef RENDER_TERRAIN
        vec3 midBlockOffset = at_midBlock.xyz / 64.0;

        int blockId = int(mc_Entity.x + EPSILON);
        vOut.blockId = blockId;

        vec3 velocity = vec3(0.0);

        #if defined(WATER_WAVE_ENABLED) && defined(RENDER_TRANSLUCENT)
            if (blockId == BLOCK_WATER) {
                float waveHeight = WaterWave_Vertex(vOut.localPos);

                float viewDist = length(viewPos);
                float waveFadeF = smoothstep(0.0, 2.0, viewDist);
                #ifdef LOD_ENABLED
                    waveFadeF *= smoothstep(dh_clipDistF * far, 0.8 * dh_clipDistF * far, viewDist);
                #endif

                vOut.waveStrength = 1.0;
                #ifdef VOXEL_ENABLED
                    vec3 originPos_up = vOut.localPos + midBlockOffset;
                    originPos_up.y += 1.0;

                    ivec3 voxelPos_up = ivec3(GetVoxelPosition(originPos_up));
                    if (IsInVoxelBounds(voxelPos_up)) {
                        uint voxel_up = texelFetch(texVoxels, voxelPos_up, 0).r;
                        if (voxel_up == BLOCK_ICE || voxel_up == BLOCK_GLASS) vOut.waveStrength = 0.0;
                    }
                #endif

                vOut.waveHeight = (waveHeight*0.5 - 0.4) * waveFadeF;
                vOut.localPos.y += vOut.waveHeight;
            }
        #endif

        #ifdef WIND_ENABLED
            if (blockId > 0 && blockId < 256*256) {
            #ifdef VELOCITY_ENABLED
                vec3 windOffset = GetWindWavingOffset(vOut.localPos, midBlockOffset, blockId, velocity, scene.WavingAnimF, scene.WavingAnimLastF);
            #else
                vec3 windOffset = GetWindWavingOffset(vOut.localPos, midBlockOffset, blockId, scene.WavingAnimF);
            #endif

            vOut.localPos += windOffset;
            }
        #endif

        #if defined(WATER_WAVE_ENABLED) || defined(WIND_ENABLED)
            viewPos = mul3(gbufferModelView, vOut.localPos);
        #endif

        #ifdef VELOCITY_ENABLED
            vOut.velocity = velocity;
        #endif
    #endif

    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);

    #ifdef TAA_ENABLED
        gl_Position.xy += taa_offset * (2.0 * gl_Position.w);
    #endif

    #if RENDER_SCALE != 0
        gl_Position.xy /= gl_Position.w;
        gl_Position.xy = gl_Position.xy * 0.5 + 0.5;
        gl_Position.xy *= RENDER_SCALE_F;
        gl_Position.xy = gl_Position.xy * 2.0 - 1.0;
        gl_Position.xy *= gl_Position.w;
    #endif

    #if defined(LIGHTING_HAND) && LIGHTING_MODE == LIGHTING_MODE_VANILLA && !defined(LIGHTING_COLORED)
        float handDist = GetHandDistance(vOut.localPos);

        float handLightLevel = max(heldBlockLightValue, heldBlockLightValue2);
        float handLight = max(handLightLevel - handDist, 0.0) / 15.0;
        vOut.lmcoord.x = max(vOut.lmcoord.x, handLight);
    #endif

    #if defined(MATERIAL_PBR_ENABLED) || defined(WATER_WAVE_ENABLED)
        vec3 viewTangent = normalize(gl_NormalMatrix * at_tangent.xyz);
        vec3 localTangent = mat3(gbufferModelViewInverse) * viewTangent;
        vOut.localTangent = packUnorm2x16(OctEncode(localTangent));
        vOut.localTangentW = at_tangent.w;
    #endif

    #ifdef MATERIAL_PARALLAX_ENABLED
        vec2 atlasTilePos, atlasTileSize;
        GetAtlasBounds(vOut.texcoord, atlasTilePos, atlasTileSize);
        vOut.atlasTilePos = packHalf2x16(atlasTilePos);
        vOut.atlasTileSize = packHalf2x16(atlasTileSize);

        mat3 matViewTBN = BuildTBN(viewNormal, viewTangent, at_tangent.w);

        vOut.tangentViewPos = viewPos.xyz * matViewTBN;

        uint wrapMask = 0u;

        #ifdef RENDER_TERRAIN
            vec3 originPos = vOut.localPos + midBlockOffset;
            vec3 voxelPos = GetVoxelPosition(originPos);

            vec3 localBitangent = normalize(cross(localNormal, localTangent));

            // left
            if (texelFetch(texVoxels, ivec3(floor(voxelPos - localTangent)), 0).r == 0u &&
                texelFetch(texVoxels, ivec3(floor(voxelPos - localTangent + localNormal)), 0).r == 0u)
                    wrapMask = bitfieldInsert(wrapMask, 1, 0, 1);

            // top
            if (texelFetch(texVoxels, ivec3(floor(voxelPos + localBitangent)), 0).r == 0u &&
                texelFetch(texVoxels, ivec3(floor(voxelPos + localBitangent + localNormal)), 0).r == 0u)
                    wrapMask = bitfieldInsert(wrapMask, 1, 1, 1);

            // right
            if (texelFetch(texVoxels, ivec3(floor(voxelPos + localTangent)), 0).r == 0u &&
                texelFetch(texVoxels, ivec3(floor(voxelPos + localTangent + localNormal)), 0).r == 0u)
                    wrapMask = bitfieldInsert(wrapMask, 1, 2, 1);

            // bottom
            if (texelFetch(texVoxels, ivec3(floor(voxelPos - localBitangent)), 0).r == 0u &&
                texelFetch(texVoxels, ivec3(floor(voxelPos - localBitangent + localNormal)), 0).r == 0u)
                    wrapMask = bitfieldInsert(wrapMask, 1, 3, 1);
        #endif

        vOut.wrapMask = wrapMask;
    #endif
}
