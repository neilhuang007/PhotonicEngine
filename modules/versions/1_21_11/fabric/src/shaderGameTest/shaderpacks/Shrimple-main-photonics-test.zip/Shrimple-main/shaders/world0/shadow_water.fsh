#version 430 compatibility

#define RENDER_TRANSLUCENT

#include "overworld.glsl"
#include "/program/shadow.fsh"
