#include "/lib/constants.glsl"
#include "/lib/common.glsl"

varying vec4 starData;
out vec3 localPos;

uniform int renderStage;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;

#ifdef TAA_ENABLED
    uniform vec2 taa_offset = vec2(0.0);
#endif


void main() {
    #ifdef SKY_STARS_FANCY
        if (renderStage == MC_RENDER_STAGE_STARS) {
            gl_Position = vec4(-2.0);
            return;
        }
    #endif

    gl_Position = ftransform();

    bool is_star = all(greaterThan(gl_Color.rgb, vec3(0.0)));
    starData = vec4(gl_Color.rgb, is_star);

    vec3 viewPos = (gbufferProjectionInverse * gl_Position).xyz;
    localPos = mat3(gbufferModelViewInverse) * viewPos;

    #ifdef TAA_ENABLED
        gl_Position.xy += taa_offset * (2.0 * gl_Position.w);
    #endif

    #if RENDER_SCALE != 0
        gl_Position.xy /= gl_Position.w;
        gl_Position.xy = gl_Position.xy * 0.5 + 0.5;
        gl_Position.xy *= RENDER_SCALE_F;
        gl_Position.xy = gl_Position.xy * 2.0 - 1.0;
        gl_Position.xy *= gl_Position.w;
    #endif
}
