#version 430 compatibility

#define RENDER_TERRAIN
#define RENDER_TRANSLUCENT

#include "end.glsl"
#include "/program/gbuffers_main.vsh"
