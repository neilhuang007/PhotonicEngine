#version 430 compatibility

#define RENDER_SOLID

#include "end.glsl"
#include "/program/shadow.fsh"
