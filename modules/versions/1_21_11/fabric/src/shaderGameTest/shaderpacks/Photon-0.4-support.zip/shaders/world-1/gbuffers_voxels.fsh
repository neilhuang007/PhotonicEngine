#version 430 compatibility

#define WORLD_NETHER
#define PROGRAM_GBUFFERS_VOXELS
#define fsh

#include "/program/gbuffers_all_solid.fsh"